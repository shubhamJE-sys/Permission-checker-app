package app.permcheck

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlarmManager
import android.app.AppOpsManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.WallpaperManager
import android.app.role.RoleManager
import android.app.usage.UsageStatsManager
import android.bluetooth.BluetoothManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorManager
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.provider.CalendarContract
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.TelephonyManager
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Kind { RUNTIME, SPECIAL, NORMAL }

data class Item(
    val id: String,
    val title: String,
    val kind: Kind,
    val perm: String? = null,
    val minSdk: Int = 1,
    val maxSdk: Int = 99
)

class RowViews(
    val item: Item,
    val statusTv: TextView,
    val resultTv: TextView,
    val flagCb: CheckBox,
    val noteEt: EditText
)

@SuppressLint("MissingPermission", "HardwareIds", "InlinedApi", "NewApi")
@Suppress("DEPRECATION")
class MainActivity : Activity() {

    private val GREEN = Color.parseColor("#4CD964")
    private val RED = Color.parseColor("#FF6B6B")
    private val ORANGE = Color.parseColor("#FFB347")
    private val GREY = Color.parseColor("#9AA5B1")

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private val rows = LinkedHashMap<String, RowViews>()
    private val lastStatus = HashMap<String, String>()
    private val lastResult = HashMap<String, String>()
    private val logLines = ArrayList<String>()
    private lateinit var generalNote: EditText
    private lateinit var crashTv: TextView
    private var requestStartedAt = 0L

    private fun p(name: String) = "android.permission.$name"

    private val sections: List<Pair<String, List<Item>>> = listOf(
        "Special access (switched on in Settings)" to listOf(
            Item("default_home", "Default home app (launcher)", Kind.SPECIAL, minSdk = 29),
            Item("overlay", "Display over other apps", Kind.SPECIAL, p("SYSTEM_ALERT_WINDOW")),
            Item("usage", "Usage access", Kind.SPECIAL, p("PACKAGE_USAGE_STATS")),
            Item("listener", "Notification access", Kind.SPECIAL),
            Item("write_settings", "Modify system settings", Kind.SPECIAL, p("WRITE_SETTINGS")),
            Item("all_files", "All files access", Kind.SPECIAL, p("MANAGE_EXTERNAL_STORAGE"), minSdk = 30),
            Item("exact_alarm", "Alarms & reminders (exact)", Kind.SPECIAL, p("SCHEDULE_EXACT_ALARM"), minSdk = 31),
            Item("install_apps", "Install unknown apps", Kind.SPECIAL, p("REQUEST_INSTALL_PACKAGES"), minSdk = 26),
            Item("battery", "Ignore battery optimisation", Kind.SPECIAL, p("REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"), minSdk = 23),
            Item("dnd", "Do Not Disturb access", Kind.SPECIAL, p("ACCESS_NOTIFICATION_POLICY"), minSdk = 23)
        ),
        "Normal (granted at install)" to listOf(
            Item("n_expand", "Expand status bar", Kind.NORMAL, p("EXPAND_STATUS_BAR")),
            Item("n_query", "See all installed apps", Kind.NORMAL, p("QUERY_ALL_PACKAGES"), minSdk = 30),
            Item("n_wallpaper", "Set wallpaper", Kind.NORMAL, p("SET_WALLPAPER")),
            Item("n_vibrate", "Vibrate", Kind.NORMAL, p("VIBRATE")),
            Item("n_internet", "Internet", Kind.NORMAL, p("INTERNET")),
            Item("n_netstate", "Network state", Kind.NORMAL, p("ACCESS_NETWORK_STATE")),
            Item("n_wifistate", "Wi-Fi state", Kind.NORMAL, p("ACCESS_WIFI_STATE"))
        ),
        "Runtime (pop-up asks you)" to listOf(
            Item("r_notif", "Notifications", Kind.RUNTIME, p("POST_NOTIFICATIONS"), minSdk = 33),
            Item("r_loc_fine", "Location (precise)", Kind.RUNTIME, p("ACCESS_FINE_LOCATION")),
            Item("r_loc_coarse", "Location (approximate)", Kind.RUNTIME, p("ACCESS_COARSE_LOCATION")),
            Item("r_loc_bg", "Location (all the time)", Kind.RUNTIME, p("ACCESS_BACKGROUND_LOCATION"), minSdk = 29),
            Item("r_camera", "Camera", Kind.RUNTIME, p("CAMERA")),
            Item("r_mic", "Microphone", Kind.RUNTIME, p("RECORD_AUDIO")),
            Item("r_contacts", "Contacts (read)", Kind.RUNTIME, p("READ_CONTACTS")),
            Item("r_contacts_w", "Contacts (write)", Kind.RUNTIME, p("WRITE_CONTACTS")),
            Item("r_calendar", "Calendar (read)", Kind.RUNTIME, p("READ_CALENDAR")),
            Item("r_phone", "Phone state", Kind.RUNTIME, p("READ_PHONE_STATE")),
            Item("r_call", "Make phone calls", Kind.RUNTIME, p("CALL_PHONE")),
            Item("r_calllog", "Call log (read)", Kind.RUNTIME, p("READ_CALL_LOG")),
            Item("r_sms", "SMS (read)", Kind.RUNTIME, p("READ_SMS")),
            Item("r_sendsms", "SMS (send)", Kind.RUNTIME, p("SEND_SMS")),
            Item("r_img", "Photos", Kind.RUNTIME, p("READ_MEDIA_IMAGES"), minSdk = 33),
            Item("r_vid", "Videos", Kind.RUNTIME, p("READ_MEDIA_VIDEO"), minSdk = 33),
            Item("r_aud", "Music & audio", Kind.RUNTIME, p("READ_MEDIA_AUDIO"), minSdk = 33),
            Item("r_sel", "Selected photos only", Kind.RUNTIME, p("READ_MEDIA_VISUAL_USER_SELECTED"), minSdk = 34),
            Item("r_storage", "Storage (old, up to Android 12)", Kind.RUNTIME, p("READ_EXTERNAL_STORAGE"), maxSdk = 32),
            Item("r_body", "Body sensors", Kind.RUNTIME, p("BODY_SENSORS")),
            Item("r_activity", "Physical activity", Kind.RUNTIME, p("ACTIVITY_RECOGNITION"), minSdk = 29),
            Item("r_bt_conn", "Bluetooth connect", Kind.RUNTIME, p("BLUETOOTH_CONNECT"), minSdk = 31),
            Item("r_bt_scan", "Bluetooth scan", Kind.RUNTIME, p("BLUETOOTH_SCAN"), minSdk = 31),
            Item("r_wifi_near", "Nearby Wi-Fi devices", Kind.RUNTIME, p("NEARBY_WIFI_DEVICES"), minSdk = 33)
        )
    )

    private val allItems: List<Item> get() = sections.flatMap { it.second }

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun now(): String = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
    private fun stamp(): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("permcheck", MODE_PRIVATE)
        prefs.getString("log", "")?.split("\n")?.filter { it.isNotBlank() }?.let { logLines.addAll(it) }
        installCrashHandler()
        buildUi()
        log("App opened")
    }

    override fun onResume() {
        super.onResume()
        refreshAll(logChanges = true)
    }

    // ---------------------------------------------------------------- logging / crash

    private fun log(msg: String) {
        logLines.add("${now()} $msg")
        while (logLines.size > 150) logLines.removeAt(0)
        prefs.edit().putString("log", logLines.joinToString("\n")).apply()
    }

    private fun installCrashHandler() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                prefs.edit().putString("crash", "${stamp()} thread=${t.name}\n$sw").commit()
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(t, e)
        }
    }

    // ---------------------------------------------------------------- UI

    private fun rounded(color: Int, radiusDp: Int = 12): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun smallButton(label: String, weight: Float = 1f, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 12f
            minHeight = dp(38)
            minimumHeight = dp(38)
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(6), 0, dp(6), 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight)
                .apply { setMargins(dp(2), 0, dp(2), 0) }
            setOnClickListener { onClick() }
        }

    private fun text(s: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = s
            textSize = sizeSp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun buildUi() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(24))
        }

        content.addView(text("PermCheck", 24f, Color.WHITE, true))
        content.addView(text(deviceLine(), 12f, GREY).apply { setPadding(0, dp(2), 0, dp(8)) })

        val explain = text(
            "1) Ask / Settings to change a permission.  2) Test to check it really works.  " +
                "3) Tick Bug on anything wrong.  4) Share report and send it to Claude.",
            12.5f, Color.parseColor("#C8D1DA")
        )
        content.addView(explain)

        val top1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, 0)
        }
        top1.addView(smallButton("Refresh") { refreshAll(true); toast("Refreshed") })
        top1.addView(smallButton("Ask all runtime") { askAllRuntime() })
        top1.addView(smallButton("Test all") { testAll() })
        content.addView(top1)

        val top2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(6), 0, 0)
        }
        top2.addView(smallButton("App info") { openAppInfo() })
        top2.addView(smallButton("Copy report") { copyReport() })
        top2.addView(smallButton("Share report") { shareReport() })
        content.addView(top2)

        generalNote = EditText(this).apply {
            hint = "What went wrong? (optional note for the report)"
            setHintTextColor(GREY)
            setTextColor(Color.WHITE)
            textSize = 13f
            minLines = 2
            gravity = Gravity.TOP
            background = rounded(Color.parseColor("#1B222B"))
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        content.addView(generalNote, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) })

        crashTv = text("", 12f, RED).apply { setPadding(0, dp(6), 0, 0) }
        content.addView(crashTv)
        updateCrashView()

        for ((title, list) in sections) {
            content.addView(text(title.uppercase(Locale.US), 12f, Color.parseColor("#7FB2FF"), true).apply {
                setPadding(0, dp(18), 0, dp(6))
            })
            for (item in list) content.addView(buildRow(item))
        }

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#101418"))
            isFillViewport = true
            clipToPadding = false
            addView(content)
        }
        scroll.setOnApplyWindowInsetsListener { v, ins ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                v.setPadding(b.left, b.top, b.right, b.bottom)
            } else {
                v.setPadding(
                    ins.systemWindowInsetLeft, ins.systemWindowInsetTop,
                    ins.systemWindowInsetRight, ins.systemWindowInsetBottom
                )
            }
            ins
        }
        setContentView(scroll)
    }

    private fun updateCrashView() {
        val c = prefs.getString("crash", null)
        if (c.isNullOrBlank()) {
            crashTv.visibility = View.GONE
        } else {
            crashTv.visibility = View.VISIBLE
            crashTv.text = "Last crash was saved and will be included in the report. (Tap to clear)"
            crashTv.setOnClickListener {
                prefs.edit().remove("crash").apply()
                updateCrashView()
            }
        }
    }

    private fun buildRow(item: Item): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor("#1B222B"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
        }
        box.addView(text(item.title, 15f, Color.WHITE, true))
        box.addView(text(item.perm?.removePrefix("android.permission.") ?: "(no manifest permission)", 11f, GREY))
        val statusTv = text("…", 13f, GREY, true).apply { setPadding(0, dp(4), 0, 0) }
        box.addView(statusTv)
        val resultTv = text("", 12f, Color.parseColor("#C8D1DA")).apply {
            setPadding(0, dp(2), 0, 0)
            visibility = View.GONE
        }
        box.addView(resultTv)

        val noteEt = EditText(this).apply {
            hint = "What happened with this one?"
            setHintTextColor(GREY)
            setTextColor(Color.WHITE)
            textSize = 12.5f
            visibility = View.GONE
            background = rounded(Color.parseColor("#0F1317"), 8)
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val flagCb = CheckBox(this).apply {
            text = "Bug"
            setTextColor(Color.WHITE)
            textSize = 12f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnCheckedChangeListener { _, on -> noteEt.visibility = if (on) View.VISIBLE else View.GONE }
        }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
            gravity = Gravity.CENTER_VERTICAL
        }
        when (item.kind) {
            Kind.RUNTIME -> {
                buttons.addView(smallButton("Ask") { askOne(item) })
                buttons.addView(smallButton("Settings") { openSettingsFor(item) })
            }
            Kind.SPECIAL -> buttons.addView(smallButton("Open settings", 2f) { openSettingsFor(item) })
            Kind.NORMAL -> {}
        }
        buttons.addView(smallButton("Test") { testOne(item) })
        buttons.addView(flagCb)
        box.addView(buttons)
        box.addView(noteEt, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) })

        rows[item.id] = RowViews(item, statusTv, resultTv, flagCb, noteEt)
        return box
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- status

    private fun applicable(item: Item) =
        Build.VERSION.SDK_INT >= item.minSdk && Build.VERSION.SDK_INT <= item.maxSdk

    private fun specialOn(id: String): Boolean = when (id) {
        "default_home" -> if (Build.VERSION.SDK_INT >= 29)
            getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_HOME) else false
        "overlay" -> Settings.canDrawOverlays(this)
        "write_settings" -> Settings.System.canWrite(this)
        "usage" -> {
            val ops = getSystemService(AppOpsManager::class.java)
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) ==
                AppOpsManager.MODE_ALLOWED
        }
        "listener" -> (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "")
            .contains(packageName)
        "all_files" -> if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else false
        "exact_alarm" -> if (Build.VERSION.SDK_INT >= 31)
            getSystemService(AlarmManager::class.java).canScheduleExactAlarms() else true
        "install_apps" -> packageManager.canRequestPackageInstalls()
        "battery" -> getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
        "dnd" -> getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted
        else -> false
    }

    private fun isOk(item: Item): Boolean = when (item.kind) {
        Kind.SPECIAL -> specialOn(item.id)
        else -> checkSelfPermission(item.perm!!) == PackageManager.PERMISSION_GRANTED
    }

    private fun statusOf(item: Item): Pair<String, Int> {
        if (!applicable(item)) return "Not applicable on Android ${Build.VERSION.RELEASE}" to GREY
        return when (item.kind) {
            Kind.SPECIAL -> if (specialOn(item.id)) "ON" to GREEN else "OFF" to RED
            Kind.NORMAL -> if (isOk(item)) "GRANTED" to GREEN else "NOT GRANTED (not in manifest?)" to RED
            Kind.RUNTIME -> {
                val perm = item.perm!!
                when {
                    isOk(item) -> "GRANTED" to GREEN
                    shouldShowRequestPermissionRationale(perm) -> "DENIED – can ask again" to ORANGE
                    prefs.getBoolean("asked_$perm", false) -> "BLOCKED – use Settings" to RED
                    else -> "NOT ASKED YET" to GREY
                }
            }
        }
    }

    private fun refreshAll(logChanges: Boolean) {
        for ((id, r) in rows) {
            val (s, c) = statusOf(r.item)
            r.statusTv.text = s
            r.statusTv.setTextColor(c)
            val old = lastStatus[id]
            if (logChanges && old != null && old != s) log("Status changed: ${r.item.title}: $old -> $s")
            lastStatus[id] = s
        }
    }

    // ---------------------------------------------------------------- asking / settings

    private fun askOne(item: Item) {
        if (!applicable(item)) {
            toast("Not applicable on this Android version"); return
        }
        val perm = item.perm ?: return
        if (isOk(item)) {
            toast("Already granted"); return
        }
        prefs.edit().putBoolean("asked_$perm", true).apply()
        requestStartedAt = System.currentTimeMillis()
        log("Asked: ${item.title} (rationale=${shouldShowRequestPermissionRationale(perm)})")
        requestPermissions(arrayOf(perm), 100)
    }

    private fun askAllRuntime() {
        val list = allItems.filter {
            it.kind == Kind.RUNTIME && applicable(it) && !isOk(it) && it.id != "r_loc_bg"
        }
        if (list.isEmpty()) {
            toast("Nothing left to ask"); return
        }
        val e = prefs.edit()
        list.forEach { e.putBoolean("asked_${it.perm}", true) }
        e.apply()
        requestStartedAt = System.currentTimeMillis()
        log("Asked all runtime: ${list.size} permissions (background location is asked on its own)")
        requestPermissions(list.map { it.perm!! }.toTypedArray(), 101)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val ms = System.currentTimeMillis() - requestStartedAt
        if (permissions.isEmpty()) {
            log("Request returned empty (request cancelled) after $ms ms")
        }
        for (i in permissions.indices) {
            val ok = grantResults.getOrNull(i) == PackageManager.PERMISSION_GRANTED
            val note = if (!ok && ms < 300) " (answered in $ms ms: system probably showed NO dialog = blocked)" else ""
            log("Result: ${permissions[i].removePrefix("android.permission.")} = " +
                (if (ok) "GRANTED" else "DENIED") +
                " rationale=${shouldShowRequestPermissionRationale(permissions[i])}$note")
        }
        refreshAll(logChanges = false)
    }

    private fun openAppInfo() {
        log("Opened App info")
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun openSettingsFor(item: Item) {
        val pkg = Uri.parse("package:$packageName")
        val intent: Intent = when (item.id) {
            "default_home" -> Intent(Settings.ACTION_HOME_SETTINGS)
            "overlay" -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)
            "write_settings" -> Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkg)
            "usage" -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            "listener" -> Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            "all_files" -> Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkg)
            "exact_alarm" -> Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg)
            "install_apps" -> Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, pkg)
            "battery" -> Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg)
            "dnd" -> Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            else -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)
        }
        try {
            log("Opened settings for ${item.title}")
            startActivity(intent)
        } catch (e: Throwable) {
            log("Settings screen for ${item.title} failed (${e.javaClass.simpleName}); opened App info instead")
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg))
            } catch (e2: Throwable) {
                log("App info also failed: ${e2.javaClass.simpleName}")
                toast("Could not open settings")
            }
        }
    }

    // ---------------------------------------------------------------- tests

    private fun testAll() {
        log("Test all started")
        allItems.filter { applicable(it) }.forEach { testOne(it, quiet = true) }
        toast("Running all tests")
    }

    private fun testOne(item: Item, quiet: Boolean = false) {
        val r = rows[item.id] ?: return
        fun finish(res: String) {
            handler.post {
                lastResult[item.id] = "${now()} $res"
                r.resultTv.visibility = View.VISIBLE
                r.resultTv.text = "Test: $res"
                log("Test ${item.title}: $res")
                refreshAll(false)
            }
        }
        if (!applicable(item)) {
            finish("Skipped – not applicable on this Android version"); return
        }
        if (!isOk(item)) {
            finish("Skipped – not granted / not on yet"); return
        }
        try {
            runTest(item.id, ::finish)
        } catch (e: Throwable) {
            finish("FAILED: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun count(uri: Uri): String {
        val c = contentResolver.query(uri, arrayOf("_id"), null, null, null)
            ?: return "query returned null (blocked?)"
        return c.use { "OK, ${it.count} rows" }
    }

    private fun runTest(id: String, done: (String) -> Unit) {
        when (id) {
            "default_home" -> {
                val home = packageManager.resolveActivity(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY
                )?.activityInfo?.packageName
                done("Current home app: $home")
            }
            "overlay" -> {
                val wm = getSystemService(WindowManager::class.java)
                val tv = TextView(this).apply {
                    text = "  overlay works  "
                    setTextColor(Color.WHITE)
                    setBackgroundColor(0xCC000000.toInt())
                    setPadding(30, 20, 30, 20)
                }
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                ).apply { gravity = Gravity.TOP }
                wm.addView(tv, lp)
                handler.postDelayed({ try { wm.removeView(tv) } catch (_: Throwable) {} }, 2000)
                done("OK, overlay shown for 2 s")
            }
            "usage" -> {
                val usm = getSystemService(UsageStatsManager::class.java)
                val end = System.currentTimeMillis()
                val list = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, end - 86_400_000L, end)
                done("OK, ${list?.size ?: 0} apps with usage in last 24 h")
            }
            "listener" -> {
                val l = PermCheckListener.instance
                if (l == null) done("Access is on but the listener is NOT connected (switch it off and on, or reopen the app)")
                else done("Connected, ${l.activeNotifications?.size ?: 0} active notifications visible")
            }
            "write_settings" -> {
                val b = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS)
                val ok = Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, b)
                done("Wrote brightness $b back: ${if (ok) "OK" else "refused"}")
            }
            "all_files" -> {
                val n = Environment.getExternalStorageDirectory().listFiles()?.size
                done(if (n == null) "Could not list storage root" else "OK, $n items in storage root")
            }
            "exact_alarm" -> done("canScheduleExactAlarms = ${getSystemService(AlarmManager::class.java).canScheduleExactAlarms()}")
            "install_apps" -> done("canRequestPackageInstalls = ${packageManager.canRequestPackageInstalls()}")
            "battery" -> done("Ignoring battery optimisation = " +
                getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName))
            "dnd" -> done("Interruption filter = ${getSystemService(NotificationManager::class.java).currentInterruptionFilter} (1 all, 2 priority, 3 none, 4 alarms)")

            "n_expand" -> {
                val sb = getSystemService("statusbar")
                sb.javaClass.getMethod("expandNotificationsPanel").invoke(sb)
                done("Called expandNotificationsPanel – the shade should have opened")
            }
            "n_query" -> {
                val apps = packageManager.getInstalledApplications(0).size
                val launchable = packageManager.queryIntentActivities(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
                ).size
                done("Sees $apps installed apps, $launchable launchable")
            }
            "n_wallpaper" -> {
                val wm = WallpaperManager.getInstance(this)
                done("isSetWallpaperAllowed=${wm.isSetWallpaperAllowed}, isWallpaperSupported=${wm.isWallpaperSupported}")
            }
            "n_vibrate" -> {
                val v = getSystemService(android.os.Vibrator::class.java)
                done("hasVibrator=${v.hasVibrator()}")
            }
            "n_internet", "n_netstate" -> {
                val cm = getSystemService(ConnectivityManager::class.java)
                val caps = cm.getNetworkCapabilities(cm.activeNetwork)
                val t = when {
                    caps == null -> "no active network"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
                    else -> "other"
                }
                val validated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                done("Active network: $t, validated=$validated")
            }
            "n_wifistate" -> {
                val w = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                done("Wi-Fi enabled=${w.isWifiEnabled}")
            }

            "r_notif" -> {
                val nm = getSystemService(NotificationManager::class.java)
                nm.createNotificationChannel(NotificationChannel("permcheck", "PermCheck test", NotificationManager.IMPORTANCE_DEFAULT))
                val n = android.app.Notification.Builder(this, "permcheck")
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("PermCheck test")
                    .setContentText("If you can read this, notifications work.")
                    .build()
                nm.notify(1, n)
                done("Posted a test notification (areNotificationsEnabled=${nm.areNotificationsEnabled()})")
            }
            "r_loc_fine", "r_loc_coarse", "r_loc_bg" -> {
                val lm = getSystemService(LocationManager::class.java)
                val gps = lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
                val net = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
                var last: android.location.Location? = null
                for (prov in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
                    try { last = last ?: lm.getLastKnownLocation(prov) } catch (_: Throwable) {}
                }
                val ageMin = last?.let { (System.currentTimeMillis() - it.time) / 60000 }
                done("GPS on=$gps, network on=$net, last known fix: " +
                    (if (last == null) "none (open Maps once, then retest)" else "yes, ${ageMin} min old, accuracy ${last.accuracy.toInt()} m"))
            }
            "r_camera" -> {
                val cm = getSystemService(CameraManager::class.java)
                val ids = cm.cameraIdList
                if (ids.isEmpty()) { done("No cameras found"); return }
                cm.openCamera(ids[0], object : CameraDevice.StateCallback() {
                    override fun onOpened(c: CameraDevice) { c.close(); done("Opened camera ${ids[0]} OK (${ids.size} cameras)") }
                    override fun onDisconnected(c: CameraDevice) { c.close(); done("Camera disconnected") }
                    override fun onError(c: CameraDevice, e: Int) { c.close(); done("Camera error code $e") }
                }, handler)
            }
            "r_mic" -> {
                val rate = 16000
                val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val rec = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min)
                if (rec.state != AudioRecord.STATE_INITIALIZED) {
                    rec.release(); done("AudioRecord did not initialise"); return
                }
                rec.startRecording()
                val st = rec.recordingState
                rec.stop(); rec.release()
                done("Mic started OK (recordingState=$st)")
            }
            "r_contacts" -> done(count(ContactsContract.Contacts.CONTENT_URI))
            "r_contacts_w" -> done("Granted (nothing is written by this test)")
            "r_calendar" -> done(count(CalendarContract.Calendars.CONTENT_URI))
            "r_phone" -> {
                val tm = getSystemService(TelephonyManager::class.java)
                done("Operator='${tm.networkOperatorName}', simState=${tm.simState}, dataNetworkType=${tm.dataNetworkType}")
            }
            "r_call" -> done("Granted (no call is placed by this test)")
            "r_calllog" -> done(count(CallLog.Calls.CONTENT_URI))
            "r_sms" -> done(count(Uri.parse("content://sms/inbox")))
            "r_sendsms" -> done("Granted (no SMS is sent by this test)")
            "r_img" -> done(count(MediaStore.Images.Media.EXTERNAL_CONTENT_URI))
            "r_vid" -> done(count(MediaStore.Video.Media.EXTERNAL_CONTENT_URI))
            "r_aud" -> done(count(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI))
            "r_sel" -> done("Granted (user-selected photos access)")
            "r_storage" -> done(count(MediaStore.Images.Media.EXTERNAL_CONTENT_URI))
            "r_body" -> {
                val sm = getSystemService(SensorManager::class.java)
                done("Heart-rate sensor present=${sm.getDefaultSensor(Sensor.TYPE_HEART_RATE) != null}")
            }
            "r_activity" -> {
                val sm = getSystemService(SensorManager::class.java)
                done("Step counter present=${sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null}")
            }
            "r_bt_conn" -> {
                val ad = getSystemService(BluetoothManager::class.java).adapter
                done(if (ad == null) "No Bluetooth adapter" else "Bluetooth on=${ad.isEnabled}, paired devices=${ad.bondedDevices.size}")
            }
            "r_bt_scan" -> {
                val ad = getSystemService(BluetoothManager::class.java).adapter
                done("LE scanner available=${ad?.bluetoothLeScanner != null}")
            }
            "r_wifi_near" -> done("Granted (nearby Wi-Fi access)")
            else -> done("No test written for this one")
        }
    }

    // ---------------------------------------------------------------- report

    private fun deviceLine(): String {
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Throwable) { "?" }
        return "${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · " +
            "patch ${Build.VERSION.SECURITY_PATCH} · PermCheck $ver"
    }

    private fun buildReport(): String {
        val sb = StringBuilder()
        sb.append("PERMCHECK BUG REPORT\n")
        sb.append("Time: ${stamp()}\n")
        sb.append("Device: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})\n")
        sb.append("Android: ${Build.VERSION.RELEASE}, API ${Build.VERSION.SDK_INT}, patch ${Build.VERSION.SECURITY_PATCH}\n")
        sb.append("Build: ${Build.DISPLAY}\n")
        val ver = try { packageManager.getPackageInfo(packageName, 0) } catch (_: Throwable) { null }
        sb.append("PermCheck: ${ver?.versionName} (code ${if (Build.VERSION.SDK_INT >= 28) ver?.longVersionCode else ver?.versionCode})\n")
        sb.append("Screen: ${resources.displayMetrics.widthPixels}x${resources.displayMetrics.heightPixels}, density ${resources.displayMetrics.density}\n\n")

        val note = generalNote.text.toString().trim()
        if (note.isNotEmpty()) sb.append("NOTE FROM USER:\n$note\n\n")

        val flagged = rows.values.filter { it.flagCb.isChecked }
        sb.append("FLAGGED AS BUG (${flagged.size}):\n")
        if (flagged.isEmpty()) sb.append("  (none)\n")
        for (r in flagged) {
            sb.append("  * ${r.item.title}: status=${statusOf(r.item).first}")
            lastResult[r.item.id]?.let { sb.append(" | last test: $it") }
            val n = r.noteEt.text.toString().trim()
            if (n.isNotEmpty()) sb.append("\n      note: $n")
            sb.append("\n")
        }

        sb.append("\nALL STATUSES:\n")
        for ((title, list) in sections) {
            sb.append("[$title]\n")
            for (item in list) {
                sb.append("  ${item.title}: ${statusOf(item).first}")
                lastResult[item.id]?.let { sb.append(" | test: $it") }
                sb.append("\n")
            }
        }

        sb.append("\nEVENT LOG (latest last):\n")
        logLines.takeLast(80).forEach { sb.append("  $it\n") }

        val crash = prefs.getString("crash", null)
        if (!crash.isNullOrBlank()) sb.append("\nLAST CRASH:\n$crash\n")
        return sb.toString()
    }

    private fun copyReport() {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("PermCheck report", buildReport()))
        log("Report copied")
        toast("Report copied – paste it to Claude")
    }

    private fun shareReport() {
        log("Report shared")
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "PermCheck bug report")
            putExtra(Intent.EXTRA_TEXT, buildReport())
        }
        startActivity(Intent.createChooser(i, "Send report"))
    }
}
