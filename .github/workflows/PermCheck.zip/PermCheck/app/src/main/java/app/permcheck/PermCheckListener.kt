package app.permcheck

import android.service.notification.NotificationListenerService

/** Minimal listener so the "Notification access" switch exists and can be tested. */
class PermCheckListener : NotificationListenerService() {
    companion object {
        @Volatile
        var instance: PermCheckListener? = null
    }

    override fun onListenerConnected() {
        instance = this
    }

    override fun onListenerDisconnected() {
        instance = null
    }
}
