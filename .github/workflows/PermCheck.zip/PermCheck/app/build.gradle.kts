plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.permcheck"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.permcheck"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    // Fixed key inside the project: every build is signed the same way,
    // so a new APK installs as an update and keeps the app's data.
    // Never lose or change app/permcheck.keystore.
    signingConfigs {
        create("fixed") {
            storeFile = file("permcheck.keystore")
            storePassword = "permcheck123"
            keyAlias = "permcheck"
            keyPassword = "permcheck123"
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("fixed")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
